document.documentElement.classList.remove('no-js');
document.documentElement.classList.add('js');

const ShoutTheme = (() => {
  const liveRegion = () => document.querySelector('[data-live-region]');
  const cartDrawer = () => document.getElementById('ShoutCartDrawer');
  const money = (cents, currency = window.Shopify?.currency?.active || 'USD') =>
    new Intl.NumberFormat(document.documentElement.lang || 'en-US', {
      style: 'currency',
      currency
    }).format((Number(cents) || 0) / 100);

  function announce(message) {
    const node = liveRegion();
    if (node) node.textContent = message;
  }

  async function getCart() {
    const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart.js`, {
      headers: { Accept: 'application/json' }
    });
    if (!response.ok) throw new Error('Unable to load cart.');
    return response.json();
  }

  function renderCart(cart) {
    document.querySelectorAll('[data-cart-count]').forEach((node) => {
      node.textContent = cart.item_count;
    });

    const target = document.querySelector('[data-cart-drawer-content]');
    if (!target) return;

    if (!cart.item_count) {
      target.innerHTML = `
        <div class="empty-state">
          <h3>Your bag is empty.</h3>
          <p>Explore the shop to find something useful.</p>
          <a class="button" href="/collections/all">Shop all</a>
        </div>`;
      return;
    }

    const lines = cart.items.map((item, index) => `
      <article class="cart-line">
        ${item.image ? `<img src="${item.image}" alt="">` : '<div></div>'}
        <div class="cart-line__copy">
          <strong><a href="${item.url}">${item.product_title}</a></strong>
          ${item.variant_title ? `<span>${item.variant_title}</span>` : ''}
          <span>Qty ${item.quantity} · ${money(item.final_line_price)}</span>
          <button class="text-button" type="button" data-cart-remove="${index + 1}">Remove</button>
        </div>
      </article>
    `).join('');

    target.innerHTML = `
      <div>${lines}</div>
      <div class="cart-drawer__subtotal">
        <span>Subtotal</span>
        <strong>${money(cart.total_price)}</strong>
      </div>
      <a class="button" href="/checkout">Secure checkout</a>
      <a class="button-ghost" href="/cart">View bag</a>`;
  }

  async function refreshCart(open = false) {
    try {
      const cart = await getCart();
      renderCart(cart);
      if (open) openCart();
      return cart;
    } catch (error) {
      announce(error.message || 'Unable to load cart.');
    }
  }

  function openCart() {
    const drawer = cartDrawer();
    if (!drawer) return;
    drawer.hidden = false;
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('drawer-open');
    drawer.querySelector('[data-cart-close]')?.focus();
  }

  function closeCart() {
    const drawer = cartDrawer();
    if (!drawer) return;
    drawer.hidden = true;
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('drawer-open');
  }

  async function addProduct(form) {
    const submit = form.querySelector('[type="submit"]');
    const original = submit?.textContent;
    if (submit) {
      submit.disabled = true;
      submit.textContent = 'Adding…';
    }

    try {
      const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart/add.js`, {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: new FormData(form)
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.description || 'Unable to add item.');
      announce(`${payload.product_title || 'Item'} added to bag.`);
      await refreshCart(true);
    } catch (error) {
      announce(error.message || 'Unable to add item.');
    } finally {
      if (submit) {
        submit.disabled = false;
        submit.textContent = original;
      }
    }
  }

  async function removeLine(line) {
    const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart/change.js`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ line, quantity: 0 })
    });
    const cart = await response.json();
    if (!response.ok) throw new Error(cart.description || 'Unable to update bag.');
    renderCart(cart);
    announce('Item removed from bag.');
  }

  function bind() {
    document.addEventListener('click', (event) => {
      const open = event.target.closest('[data-cart-open]');
      const close = event.target.closest('[data-cart-close]');
      const remove = event.target.closest('[data-cart-remove]');
      const menu = event.target.closest('[data-menu-toggle]');

      if (open) {
        event.preventDefault();
        refreshCart(true);
      }
      if (close) {
        event.preventDefault();
        closeCart();
      }
      if (remove) {
        event.preventDefault();
        removeLine(Number(remove.dataset.cartRemove)).catch((error) => announce(error.message));
      }
      if (menu) {
        const nav = document.getElementById('MobileNav');
        const expanded = menu.getAttribute('aria-expanded') === 'true';
        menu.setAttribute('aria-expanded', String(!expanded));
        if (nav) nav.hidden = expanded;
      }
    });

    document.addEventListener('submit', (event) => {
      const form = event.target.closest('[data-product-form]');
      if (!form) return;
      event.preventDefault();
      addProduct(form);
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeCart();
    });

    refreshCart(false);
  }

  return { bind, refreshCart };
})();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', ShoutTheme.bind);
} else {
  ShoutTheme.bind();
}
