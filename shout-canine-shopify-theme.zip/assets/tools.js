(() => {
  function initBodyLanguage() {
    document.querySelectorAll('[data-body-language-tool]').forEach((root) => {
      const buttons = [...root.querySelectorAll('[data-signal]')];
      const title = root.querySelector('[data-signal-title]');
      const body = root.querySelector('[data-signal-body]');
      const data = {
        eyes: ['Eyes', 'Notice eye shape, blinking, hard staring, gaze shifts, and visible sclera. Combine eye information with the rest of the dog.'],
        ears: ['Ears', 'Ear position can shift with attention and emotional state. Breed anatomy and the dog’s normal carriage matter.'],
        mouth: ['Mouth', 'Look for lip tension, panting, licking, yawning, closed-mouth stillness, vocalization, and changes from baseline.'],
        tail: ['Tail', 'A wagging tail does not automatically mean a happy dog. Notice height, stiffness, speed, range, and whole-body looseness.'],
        posture: ['Body position', 'Weight distribution can reveal approach, retreat, uncertainty, or readiness. Notice stiffness, crouching, curving, and leaning.'],
        movement: ['Movement', 'Loose, curved, rhythmic movement differs from stiff, direct, frozen, or rapidly escalating movement.']
      };
      buttons.forEach((button) => button.addEventListener('click', () => {
        buttons.forEach((b) => b.classList.remove('is-selected'));
        button.classList.add('is-selected');
        const value = data[button.dataset.signal];
        if (value && title && body) {
          title.textContent = value[0];
          body.textContent = value[1];
        }
      }));
    });
  }

  function initDogTellingMe() {
    document.querySelectorAll('[data-dog-telling-tool]').forEach((root) => {
      const groups = [...root.querySelectorAll('[data-question]')];
      const result = root.querySelector('[data-tool-result]');
      const submit = root.querySelector('[data-interpret]');
      const reset = root.querySelector('[data-reset]');

      groups.forEach((group) => {
        group.querySelectorAll('[data-weight]').forEach((button) => {
          button.addEventListener('click', () => {
            group.querySelectorAll('[data-weight]').forEach((b) => b.classList.remove('is-selected'));
            button.classList.add('is-selected');
          });
        });
      });

      submit?.addEventListener('click', () => {
        const totals = { relaxation:0, play:0, uncertainty:0, distance:0, arousal:0 };
        let count = 0;
        groups.forEach((group) => {
          const selected = group.querySelector('.is-selected[data-weight]');
          if (!selected) return;
          count += 1;
          try {
            const weights = JSON.parse(selected.dataset.weight || '{}');
            Object.entries(weights).forEach(([key, value]) => {
              if (key in totals) totals[key] += Number(value) || 0;
            });
          } catch {}
        });

        if (!result) return;
        if (count < groups.length) {
          result.hidden = false;
          result.innerHTML = '<h2>Keep observing.</h2><p>Answer each observation before interpreting this combination.</p>';
          return;
        }

        const top = Object.entries(totals).sort((a,b) => b[1]-a[1])[0][0];
        const copy = {
          relaxation: ['Relative relaxation may fit this combination', 'Loose movement and softer posture can support a relaxed interpretation when context and baseline agree.'],
          play: ['Playful intent may fit this combination', 'Bouncy movement, role changes, pauses, and voluntary re-engagement often support playful interpretations.'],
          uncertainty: ['This combination may reflect uncertainty', 'Hesitation, lowered posture, pinned ears, tension, or displacement can occur when a dog is unsure.'],
          distance: ['The dog may be asking for more distance', 'Turning away, retreating, leaning back, freezing, or trying to leave can function as distance-increasing behavior.'],
          arousal: ['This combination may reflect increased arousal', 'Stiffness, forward weight, intense orientation, sudden stillness, or escalating vocalization can accompany higher arousal.']
        }[top];

        result.hidden = false;
        result.innerHTML = `<p class="eyebrow">Educational interpretation</p><h2>${copy[0]}</h2><p>${copy[1]}</p><p><strong>Important:</strong> This is educational, not a behavioral diagnosis. Read the entire dog and context.</p>`;
      });

      reset?.addEventListener('click', () => {
        root.querySelectorAll('.is-selected').forEach((b) => b.classList.remove('is-selected'));
        if (result) result.hidden = true;
      });
    });
  }

  function initEnrichment() {
    document.querySelectorAll('[data-enrichment-tool]').forEach((root) => {
      const form = root.querySelector('form');
      const output = root.querySelector('[data-enrichment-output]');
      if (!form || !output) return;

      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const fd = new FormData(form);
        const age = fd.get('age');
        const energy = fd.get('energy');
        const food = fd.get('food');
        const mobility = fd.get('mobility');
        const environment = fd.get('environment');
        const time = fd.get('time');

        const limited = mobility !== 'none' || age === 'senior';
        const warmup = limited
          ? 'Begin with slow sniffing and easy movement on stable, non-slip footing.'
          : energy === 'high'
            ? 'Begin with calm sniffing before adding more active work.'
            : 'Begin with a short decompression sniff or orientation game.';

        let main = food !== 'low'
          ? 'Create a scent-search game using part of the dog’s normal food portion.'
          : 'Create a simple search game using a favorite toy or familiar object.';

        if (limited) main = 'Use low-impact scent stations at nose level with stable footing and no jumping.';
        if (environment === 'outdoor' && energy === 'high' && !limited) main = 'Build a supervised outdoor search route with scent stations and deliberate pauses.';

        const challenge = time === '10'
          ? 'Change one hiding location for a small increase in difficulty.'
          : time === '40'
            ? 'Add a second search area and a short, easy training game.'
            : 'Add one new hiding place or surface while keeping the success rate high.';

        output.innerHTML = `
          <p class="eyebrow">Today’s plan</p>
          <h2>Simple. Useful. Adjustable.</h2>
          <h3>Warm-up</h3><p>${warmup}</p>
          <h3>Main activity</h3><p>${main}</p>
          <h3>Calming finish</h3><p>Finish with lower-arousal sniffing, licking, chewing, or quiet observation when appropriate.</p>
          <h3>Optional challenge</h3><p>${challenge}</p>
          <p><strong>Safety:</strong> Supervise new activities, use safe materials, account for food calories, and stop if distress, pain, or unsafe behavior appears.</p>`;
      });
    });
  }

  function initPlayQuiz() {
    document.querySelectorAll('[data-play-quiz]').forEach((root) => {
      root.querySelectorAll('[data-play-choice]').forEach((button) => {
        button.addEventListener('click', () => {
          const correct = button.dataset.playChoice === button.dataset.correct;
          const output = root.querySelector('[data-play-feedback]');
          root.querySelectorAll('[data-play-choice]').forEach((b) => b.classList.remove('is-selected'));
          button.classList.add('is-selected');
          if (output) {
            output.hidden = false;
            output.innerHTML = correct
              ? '<strong>Good read.</strong><p>Look for reciprocity, pauses, voluntary re-engagement, loose movement, and easy disengagement.</p>'
              : '<strong>Look again.</strong><p>Avoid judging play from one behavior alone. Notice whether both dogs retain choice and whether pressure is reciprocal.</p>';
          }
        });
      });
    });
  }

  function initBehaviorLog() {
    document.querySelectorAll('[data-behavior-log]').forEach((root) => {
      const form = root.querySelector('form');
      const output = root.querySelector('[data-log-output]');
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const fd = new FormData(form);
        const rows = [
          ['Dog', fd.get('dog')], ['Date', fd.get('date')], ['Environment', fd.get('environment')],
          ['Trigger / antecedent', fd.get('trigger')], ['Observed behavior', fd.get('behavior')],
          ['Intensity', `${fd.get('intensity')}/5`], ['Handler response', fd.get('response')],
          ['Recovery', fd.get('recovery')], ['Notes', fd.get('notes')]
        ];
        output.innerHTML = `<p class="eyebrow">Behavior log</p><h2>${fd.get('dog') || 'Dog'}</h2>` +
          rows.map(([key,val]) => `<p><strong>${key}:</strong> ${val || '—'}</p>`).join('') +
          '<button class="button-ghost" type="button" onclick="window.print()">Print record</button>';
      });
    });
  }

  function initProfile() {
    document.querySelectorAll('[data-dog-profile]').forEach((root) => {
      const form = root.querySelector('form');
      const output = root.querySelector('[data-profile-output]');
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const fd = new FormData(form);
        const name = fd.get('name') || 'Dog';
        const breed = String(fd.get('breed') || '');
        const energy = fd.get('energy');
        const food = fd.get('food');
        const triggers = String(fd.get('triggers') || '');
        const ideas = [];
        if (energy === 'high') ideas.push('Scent trails with decompression pauses', 'Structured movement');
        else ideas.push('Low-pressure sniffing and observation');
        if (food !== 'low') ideas.push('Scatter feeding or food-search games');
        if (breed.toLowerCase().includes('husky')) ideas.push('Novel route exploration');
        const education = triggers ? 'Reading Early Stress Signals + Behavior Log' : 'Body Language Center + Enrichment Center';
        output.innerHTML = `<p class="eyebrow">${name} profile</p><h2>${breed || 'Individual dog'}</h2>
          <p><strong>Suggested enrichment:</strong></p><ul>${ideas.map(i => `<li>${i}</li>`).join('')}</ul>
          <p><strong>Suggested education:</strong> ${education}</p>
          <p>These suggestions organize site content. They are not a diagnosis or guarantee of suitability.</p>`;
      });
    });
  }


  function initGroupPlay() {
    document.querySelectorAll('[data-group-play-tool]').forEach((root) => {
      const form = root.querySelector('form');
      const output = root.querySelector('[data-group-play-output]');
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const fd = new FormData(form);
        let score = 0;
        if (fd.get('arousal') === 'high') score += 2;
        if (fd.get('resources') === 'significant') score += 3;
        if (fd.get('resources') === 'mild') score += 1;
        if (fd.get('barriers') === 'significant') score += 2;
        if (fd.get('barriers') === 'mild') score += 1;
        if (fd.get('handling') === 'difficult') score += 2;
        if (fd.get('handling') === 'variable') score += 1;
        if (fd.get('confidence') === 'low') score += 1;

        const result = score >= 6
          ? ['High management need', 'Several factors may increase management complexity. Consider individualized introductions, lower-arousal setups, resource control, predictable handling, and close reassessment.']
          : score >= 3
            ? ['Moderate management need', 'Some factors deserve active management. Match play style and energy thoughtfully, provide easy disengagement, control resources, and reassess as arousal changes.']
            : ['Lower management complexity', 'Fewer obvious management flags are selected, but compatibility still depends on the specific dogs, environment, health, history, handler skill, and real-time behavior.'];

        output.innerHTML = `<p class="eyebrow">Organizational guidance</p><h2>${result[0]}</h2><p>${result[1]}</p>
          <p><strong>Important:</strong> This worksheet cannot determine whether two dogs are safe together. Use qualified observation, appropriate introductions, environment management, and ongoing reassessment.</p>`;
      });
    });
  }


  function initKnowledgeQuiz() {
    document.querySelectorAll('[data-knowledge-quiz]').forEach((root) => {
      const questions = [...root.querySelectorAll('[data-quiz-question]')];
      const result = root.querySelector('[data-quiz-result]');

      questions.forEach((question) => {
        question.querySelectorAll('[data-quiz-choice]').forEach((button) => {
          button.addEventListener('click', () => {
            question.querySelectorAll('[data-quiz-choice]').forEach((b) => b.classList.remove('is-selected'));
            button.classList.add('is-selected');
          });
        });
      });

      root.querySelector('[data-quiz-score]')?.addEventListener('click', () => {
        let score = 0;
        let answered = 0;
        questions.forEach((question) => {
          const selected = question.querySelector('.is-selected[data-quiz-choice]');
          const explanation = question.querySelector('[data-quiz-explanation]');
          if (selected) {
            answered += 1;
            if (selected.dataset.quizChoice === question.dataset.correct) score += 1;
          }
          if (explanation) explanation.hidden = false;
        });

        if (!result) return;
        result.hidden = false;
        result.innerHTML = answered !== questions.length
          ? `<h2>Finish every question.</h2><p>You answered ${answered} of ${questions.length}.</p>`
          : `<p class="eyebrow">Quiz result</p><h2>${score}/${questions.length}</h2><p>${score === questions.length ? 'Canine Communication Detective' : 'Keep observing the whole dog.'}</p>`;
      });

      root.querySelector('[data-quiz-reset]')?.addEventListener('click', () => {
        questions.forEach((question) => {
          question.querySelectorAll('.is-selected').forEach((b) => b.classList.remove('is-selected'));
          const explanation = question.querySelector('[data-quiz-explanation]');
          if (explanation) explanation.hidden = true;
        });
        if (result) result.hidden = true;
      });
    });
  }

  function boot() {
    initBodyLanguage();
    initDogTellingMe();
    initEnrichment();
    initPlayQuiz();
    initBehaviorLog();
    initProfile();
    initGroupPlay();
    initKnowledgeQuiz();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
